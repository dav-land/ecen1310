# maze

Welcome to our Final Project! We will be doing cool things with mazes

## Installing needed packages: 
`sudo apt-get install expect`

## Usage: 
```
make
expect run.exp
```
Passes in maze files as well as starting positions in order for all solutions to the maze to be found.
